
    <link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css">
  <link rel="stylesheet" href="css/footer/foot.css">

  


<footer>
	
		<nav id="menu_footer">
			<h5>Menu</h5>
			<ul>
				<li><a href="inicio">INICIO</a></li>
				<li><a href="nosotros">NOSOTROS</a></li>
				<li><a href="servicios">SERVICIOS</a></li>
				<li><a href="contacto">CONTACTO</a></li>
			</ul>
        </nav>
     
		<div class="localizar">
			<h5>¿Donde estamos?</h5>
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3396.760711692368!2d-60.71073328557672!3d-31.640401481330084!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95b5a9b9ee0dedef%3A0xebaccd25cb722e4a!2sOIME%20MEDICINA%20LABORAL%20PARA%20EMPRESAS!5e0!3m2!1ses-419!2sar!4v1581702330536!5m2!1ses-419!2sar" width="100%" height="250px" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
        </div>
        <div id="contacto">
           <h5>Contactate con nosotros</h5>
           <div class="face">
            		<a href="https://www.facebook.com/oimesantafesrl/" target="_blank" ><img src="images/facebook.png" alt="facebook"></a>
            		<a href="https://www.facebook.com/oimesantafesrl/" target="_blank" ><p class="overlay">@oimesantafesrl</p></a>
            </div>
            <div class="tel">
                    <a href="tel:+543424522113" target="_blank" ><img src="images/phone.png" alt="telefono"></a>
            		<a href="tel:+543424522113" target="_blank" ><p class="overlay">0342 452-2113</p></a>
            </div>
            <div class="mail">
                    <a href="mailto:oimesantafe@fibertel.com.ar?Subject=Interesado%20en%20conocer%20mas" target="_blank" title="mail secretaria" ><img src="images/mail.png" alt="mail"></a>
            		<a href="mailto:oimesantafe@fibertel.com.ar?Subject=Interesado%20en%20conocer%20mas" target="_blank" title="mail secretaria" ><p class="overlay">oimesantafe@fibertel.com.ar</p></a>
            </div>
            <div class="mail2">
                    <a href="mailto:administracion.oime@fibertel.com.ar?Subject=Interesado%20en%20conocer%20mas" target="_blank" title="mail administracion" ><img src="images/mail.png" alt="mail"></a>
            		<a href="mailto:administracion.oime@fibertel.com.ar?Subject=Interesado%20en%20conocer%20mas" target="_blank" title="mail administracion" ><p class="overlay">administracion.oime@fibertel.com.ar</p></a>
            </div>
        </div>
		<div id="info">
			
			<p>©Copyright 2020 |<a href="https://eichhorn-micaela.000webhostapp.com/"> Micaela Eichhorn </a>| All Rights Reserved</p>
		</div> 
	

</footer> 
<!-- MENSAJE DE FORMULARIO  -->
<div id="dialog" title="Mensaje enviado" style="display:none">
  <p style="color: #154360;"><span class="ui-icon ui-icon-circle-check" style="float:left; margin:0 7px 50px 0;"></span>Su mensaje ha sido enviado con exito, pronto nos comunicaremos con usted.</p>
</div>
<div id="dialog-danger" title="Mensaje no enviado" style="display:none">
  <p style="color: #154360;"><span class="ui-icon  ui-icon-alert" style="float:left; margin:0 7px 50px 0;"></span>El mensaje no se a podido enviar, intentelo mas tarde.</p>
</div>
<div id="dialog-input" title="Mensaje de error"style="display:none">
  <p class="parra"></p>
</div>

<!-- javascript-->
<script  src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
  crossorigin="anonymous"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"integrity="sha256-VazP97ZCwtekAsvgPBSUwPFKdrwD3unUfSGVYrahUqU="crossorigin="anonymous"></script>
<script  src="jquery/jqry.js"></script>


</body>
</html>