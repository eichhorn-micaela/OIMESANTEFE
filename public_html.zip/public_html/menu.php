<!DOCTYPE html>
<html lang="es">
<head>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <script>
    (adsbygoogle = window.adsbygoogle || []).push({
       google_ad_client: "ca-pub-2789378141691144",
       enable_page_level_ads: true
       });
    </script>
   <!-- Global site tag (gtag.js) - Google Analytics -->
   <script async src="https://www.googletagmanager.com/gtag/js?id=UA-165325784-3"></script>
   <script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-165325784-3');
</script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no">
    <title>Oime Santa Fe SRL | Medicina laboral</title>
    <meta name="description"content="Seguimos siendo el UNICO Instituto totalmente independiente de la ciudad de Santa Fe y de la Región, con dedicación exclusiva en Medicina Laboral." >
    <meta name="keywords" content="ocupacional, preocupacional, postocupacional, post-ocupacional, preo-ocupacinoal, examenes ocupacionales, libretas sanitarias, examenes periódicos,ausentismo,ausentismo laboral, control de ausentismo,control medico laboral,medico laboral a domicilio,medico laboral ley, control enfermedad del trabajador,faltas por enfermedad, ausente por enfermedad,control de ausentismo, medicina laboral, accidentes, examenes preocupacionales, medicina para empresas, salud, art, medicina del trabajo, carpeta medica, legitimo usuario" >
    <link rel="icon" type="image/png" href="images/medio.png">
    
    <link rel="stylesheet"  href="css/menu/menue.css">
    
    
</head>
<body>

      <header>
         <div class="encabezado">
           <img src="images/OIMELOGO.jpg" class="logo" alt="logo"  >
           <h1 style="color: #154360;">OIME SANTA FE SRL</h1>
           <img src="images/icono.svg" class="icono"  alt="icono">
         </div>
         
         <div class="menu">
           <div class="menu2"><a href="#">MENU   ></a></div>
           <nav>
             
             <ul>
               <li><a href="inicio">INICIO</a></li>
               <li><a href="nosotros">NOSOTROS</a></li>
               <li><a href="servicios">SERVICIOS</a></li>
               <li><a href="contacto">CONTACTO</a></li>  
             </ul>
           </nav>
         </div> 
      </header>
</html>
 

