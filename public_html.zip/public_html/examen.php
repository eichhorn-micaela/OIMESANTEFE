<?php include 'menu.php' ?>
<link rel="stylesheet" href="css/contacto/contacts.css">
<link rel="stylesheet" href="css/examen/exams.css">
<div class="wrap">
     <div class="titulo">
          <h2 style="color: #154360;">Contactate con nosotros</h2>
     </div>
        <section class="intro">
            <div class="texto">
                 <p style="color: #154360;">Resultado en 24 a 48hs con la más absoluta seriedad, reserva y confiabilidad,  para respaldo del empresario y la mayor eficiencia,  experiencia  y objetividad  para  determinar  la Aptitud psico-física acorde a las tareas a desempeñar por el postulante.<br>
                 <u>Indicaciones para presentarse a los examenes:</u> deben presentarse a las 8:00 am. en ayunas y con 3 hrs de retencion de liquidos (la muestra de orina debe realizarse en oime, no traer de casa), el paciente  debe presentar el DNI, la fotocopia del DNI y una foto 3 x 3. </p>
            </div>
        </section>
        <section class="contenedor-formulario">
            <h2 style="color: #154360;">Formulario de pedido de examen</h2>
            <hr>
          <div class="formulario">
              <form id="contact-form" role="form" data-toggle="validator" name="contact-form" action="mails/mail.php" method="POST" enctype="multipart/form-data">
              <fieldset class="fieldset">
                  <legend>Datos de la empresa a facturar</legend>
                  <ul>
                  <li>
                     <label for="empresa">Razón social:</label>
                     <input type="text" id="empresa" name="empresa" placeholder="Ej: OIME SRL" required >
                  </li>

                  <li>
                     <label for="cuit">Cuit:</label>
                     <input type="text" id="cuit" name="cuit"  maxlength="14" required pattern="[0-9]{2}[\-][0-9]{8}[\-][0-9]{1}" placeholder="Ej: 27-25698658-9"   >
                  </li>
                  <li>
                     <label for="email">Email:</label>
                     <input type="email" id="email" name="email" placeholder="Ej: miempresa@hotmail.com"  required  >
                  </li>
                  <li>
                     <label for="dir">Dirección:</label>
                     <input type="text" id="dir" name="dir" placeholder="Ej: Crespo 2882, Santa Fe, Argentina, cp:3000"  required  >
                  </li>
                  <li>
                     <label for="remitente">Contacto:</label>
                     <input type="text" id="remitente" name="remitente" placeholder="Ej: Carlos Rodriguez" required >
                  </li>

                  <li>
                     <label for="tel">Teléfono de contacto:</label>
                     <input type="text" id="tel" name="tel" required pattern="[0-9]*" placeholder="Ej: 4582593"   >
                  </li>
                 </ul>
                 </fieldset>
                 <div class="dividir">
                  <fieldset class="fieldset asunto">
                   <legend>Turnos</legend>
                     <select id="asunto" name="asunto" style="width:80%" required 
                     onchange="if(this.value=='Otro'){ $('#otro').css('display','block'); $('#otro').attr('required', 'true');$('#otro').attr('name', 'asunto');$(this).css('display','none');$(this).attr('required', 'false');}
                     if(this.value=='Examenes'){$('.inputs .fieldset #examen').css('display','block'); $('.inputs .fieldset #examen select').attr('required', 'true');}else{$('.inputs .fieldset #examen').css('display','none'); $('.inputs .fieldset #examen select').attr('required', 'false');}">
                        <option value="Examenes" selected>Examenes</option>
                        <option value="Carpeta medica">Carpeta medica</option>
                        <option value="Otro">Otro</option>
                     </select>
                     <input type="text" id="otro" placeholder="otro"   style="display:none">
                  
                 </fieldset> 
                 <fieldset class="fieldset asunto">
                 <legend>Adjuntar archivo</legend>
                 
                  <input type="hidden" name="MAX_FILE_SIZE" value="134217728"> <input type="file" id="file" name="file[]" multiple="multiple" >
                  
                </div>
                </fieldset>
                  
                  <fieldset class="fieldset ">
                  <legend>Datos de el o los empleados</legend>
                  <fieldset class="fieldset inputs" style="border:none;">
                 
                 </fieldset>
                 </fieldset>
                    <div class="agregar">
                        <input type="button" id="btnAdd" name="agregar"  value="Agregar empleado" />
                          
                  </div>
                  <input type="hidden" id="contar" name="contar" >
                  </fieldset> 
                  
                  <div class="enviar">
                    <div class="copia">     
                     <label for="copia" >Enviar una copia del mensaje:</lebel>
                     <input type="checkbox" name="copia"  id="copia">
                    </div>

                  <button  id="enviar" type="submit">Enviar</button>
                  </div>
              </form>

              <div class="cargando" style="text-align: center; display:none" id="barra">
              <img src="images/barra.gif" alt="Cargando..." style="width: 200px"><br>
                Enviando mensaje...        
              </div>
          </div>
        </section>
        <section class="contenido-contacto">
            <h2 style="color: #154360;">Contactate con nosotros</h2>
            <hr>
            <div class="contacto">
                <div class="datos">
                    <div>
                    <h3>Horario de atencion administrativa</h3>
                    <p>Lunes a Viernes de 8 a 12:30 y de 15:30 a 19:30</p>
                    <p>Sabados de 8 a 12</p>
                    </div>
                    <div>
                    <h3>Horario de atencion Médica</h3>
                    <p>Lunes a Viernes de 8 a 12 y de 16:30 a 19:20</p>
                    <p>Sábados de 10 a 12</p>
                    </div>

                    <div class="direccion">
            		<img src="https://i.pinimg.com/originals/03/c5/c2/03c5c27d3cd2ad04e6d4803829824ac3.png" alt="direccion">
            		<a href="https://goo.gl/maps/9hRQPYNEEoLD5GL69" target="_blank" ><p class="overlay">Crespo 2882, Santa Fe, Argentina</p></a>
                    </div>
                    <div class="tel">
                    <img src="images/phone.png" alt="telefono">
            		<a href="tel:+543424522113" target="_blank" ><p class="overlay">0342 452-2113</p></a>
                    </div>
                    <div class="mail">
                    <img src="images/mail.png" alt="mail">
            		<a href="mailto:oimesantafe@fibertel.com.ar?Subject=Interesado%20en%20conocer%20mas" target="_blank" title="mail secretaria" ><p class="overlay">oimesantafe@fibertel.com.ar</p></a>
                   </div>
                   <div class="mail2">
                    <img src="images/mail.png" alt="mail">
            		<a href="mailto:administracion.oime@fibertel.com.ar?Subject=Interesado%20en%20conocer%20mas" target="_blank" title="mail administracion" ><p class="overlay">administracion.oime@fibertel.com.ar</p></a>
            </div>
                     
                </div>
                <div class="mapa">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3396.760711692368!2d-60.7107332855767!3d-31.640401481330084!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95b5a9b9ee0dedef%3A0xebaccd25cb722e4a!2sOIME%20MEDICINA%20LABORAL%20PARA%20EMPRESAS!5e0!3m2!1ses-419!2sar!4v1582561579456!5m2!1ses-419!2sar" width="100%" height="100%" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
                </div>
            </div>
        </section>

</div>
<script
  src="https://code.jquery.com/jquery-3.5.1.min.js"
  integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
  crossorigin="anonymous"></script>
<script src="jquery/exam.js"></script>
<?php include 'footer.php' ?>