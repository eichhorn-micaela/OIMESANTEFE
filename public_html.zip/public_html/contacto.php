<?php include 'menu.php' ?>
<link rel="stylesheet" href="css/contacto/contacts.css">
<div class="wrap">
     <div class="titulo">
          <h2>Contactate con nosotros</h2>
     </div>
        <section class="intro">
            <div class="texto">
                 <p style="color: #154360;">Puedes contactarte con nosotros seleccionando uno de los 3 formularios de contacto específicos para cada gestión.</p>
            </div>
        </section>
        <section class="contenedor-botones">
            <h2 style="color: #154360;">Formularios de contacto</h2>
            <hr>
          <div class="botones">
              <div class="boton">
                  <h3>Turnos de exámenes</h3>
                   <a href="examen" ><img src="https://portal.coren-sp.gov.br/wp-content/uploads/2018/07/publicacao.png" alt="formulario"></a>
              </div>
              <div class="boton">
                  <h3>Control de ausentismo</h3>
                  <a href="ausentismo" ><img src="https://portal.coren-sp.gov.br/wp-content/uploads/2018/07/publicacao.png" alt="formulario"></a>
              </div>
              <div class="boton">
                  <h3>Administración</h3>
                  <a href="administracion" ><img src="https://portal.coren-sp.gov.br/wp-content/uploads/2018/07/publicacao.png" alt="formulario"></a>
              </div>
          </div>
        </section>
        <section class="contenido-contacto">
            <h2 style="color: #154360;">Contactate con nosotros</h2>
            <hr>
            <div class="contacto">
                <div class="datos">
                    <div>
                    <h3>Horario de atencion administrativa</h3>
                    <p>Lunes a Viernes de 8 a 12:30 y de 15:30 a 19:30</p>
                    <p>Sabados de 8 a 12</p>
                    </div>
                    <div>
                    <h3>Horario de atencion Médica</h3>
                    <p>Lunes a Viernes de 8 a 12 y de 16:30 a 19:20</p>
                    <p>Sábados de 10 a 12</p>
                    </div>

                    <div class="direccion">
            		<img src="https://i.pinimg.com/originals/03/c5/c2/03c5c27d3cd2ad04e6d4803829824ac3.png" alt="direccion">
            		<a href="https://goo.gl/maps/9hRQPYNEEoLD5GL69" target="_blank" ><p class="overlay">Gdor. Crespo 2882 S3000 Santa Fe </p></a>
                    </div>
                    <div class="tel">
                    <img src="images/phone.png" alt="telefono">
            		<a href="tel:+543424522113" target="_blank" ><p class="overlay">0342 452-2113</p></a>
                    </div>
                    <div class="mail">
                    <img src="images/mail.png" alt="mail">
            		<a href="mailto:oimesantafe@fibertel.com.ar?Subject=Interesado%20en%20conocer%20mas" target="_blank" title="mail secretaria" ><p class="overlay">oimesantafe@fibertel.com.ar</p></a>
                   </div>
                   <div class="mail2">
                    <img src="images/mail.png" alt="mail">
            		<a href="mailto:administracion.oime@fibertel.com.ar?Subject=Interesado%20en%20conocer%20mas" target="_blank" title="mail administracion" ><p class="overlay">administracion.oime@fibertel.com.ar</p></a>
            </div>
                     
                </div>
                <div class="mapa">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3396.760711692368!2d-60.7107332855767!3d-31.640401481330084!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95b5a9b9ee0dedef%3A0xebaccd25cb722e4a!2sOIME%20MEDICINA%20LABORAL%20PARA%20EMPRESAS!5e0!3m2!1ses-419!2sar!4v1582561579456!5m2!1ses-419!2sar" width="100%" height="100%" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
                </div>
            </div>
        </section>

</div>
<?php include 'footer.php' ?>