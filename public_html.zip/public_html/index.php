<?php include 'menu.php' ?>


<link rel="stylesheet"  href="css/inicio/inic.css">
<div class="wrap">
		<section class="banner">
          <div class="banner_item">
            <div id="bienvenido">
               <h1 >BIENVENIDOS A OIME SANTA FE SRL</h1>
               <a class="boton" href="nosotros.php">CONOCENOS</a>
            </div>
          </div>
          <div class="banner_item">
            <div id="medicina">
               <h1 >La mejor atención en Medicina Laboral</h1>
               <a class="boton" href="servicios.php">SERVICIOS</a>
            </div>
		  </div>
          <div class="banner_item">
            <div id="confianza">
               <h1 >Eficiencia demostrada día a día durante más de 30 años</h1>
               <a class="boton" href="contacto.php">CONTACTANOS</a>
            </div>
          </div>
          
        </section>
        <section class="elegir">
            <h2 style="color: #154360;">¿Por que elegirnos?</h2>
            <hr>
            <article class="content-porque">
                   <div>
                       
                        <ul style="color: #154360;">
                        <li>Seguimos siendo el UNICO Instituto totalmente independiente de la ciudad de Santa  Fe y de la Región,  con dedicación exclusiva en Medicina del Trabajo.-</li>

                         <li >  Somos el único Instituto de Medicina Laboral de la ciudad de Santa Fe, que ha cumplido y superado las exigencias del Ministerio de Salud Publica y Acción Social de la Nación para ser habilitado como Servicio de Medicina Laboral, logrando dicho objetivo a partir de noviembre de 1994, Inscripto con el Nº 0087 Libro I Folio 005 con carácter permanente en el Registro Nacional  de Medicina del Trabajo. </li>

                         <li >  Esta habilitación, nos permite cumplir con la Ley Nº  24.557 ( Ley de Riesgos del Trabajo), y de acuerdo al Art. Nº 8,  del Decreto 37/10 ,  nos faculta para la realización de los exámenes en salud, establecidos por dicha ley.-</li>

                         <li >  Nuestros profesionales se encuentran Inscriptos en el Registro de Profesionales adheridos al  Código de Ética para los profesionales de la Salud Ocupacional de la Superintendencia de Riesgos de Trabajo, aprobado por la Junta  Directiva de  ICOH ( Comisión Internacional de Salud Ocupacional).-</li>
                        </ul>
                       
                    </div>
                    <div>
                        <img src="images/OIMELOGO.jpg" alt="logo">
                        
                    </div>
                
        </section>
        <section class="caracteriza">
            <h2 style="color: #154360;">Lo que nos caracteriza</h2>
            <hr>
            <article class="content-caracteriza">
                <div class="colum-1">
                    <div>
                        <img src="images/profecional-icon.png" alt="logo de profesionalismo">
                        <p>Profesionalismo</p>
                    </div>
                    <div>
                        <img src="images/eficiencia-icon.png" alt="logo de eficiencia">
                        <p>Eficiencia</p>
                    </div>
                </div>
                <div class="colum-2">
                    <img src="images/medio.png" alt="logo de medicina">
                </div>
                <div class="colum-3">
                    <div>
                        <img src="images/garantia-icon.png" alt="logo de garantia">
                        <p>Garantia de resultados</p>
                    </div>
                    <div>
                        <img src="images/logoff_15259.png" alt="logo de confidencialidad">
                        <p>Confidencialidad</p>
                    </div>
                </div>
            </article>
        </section>
</div> 

<?php include 'footer.php' ?>