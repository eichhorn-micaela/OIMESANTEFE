$(document).ready(function() {
    let num = 0;
    $('#btnAdd').click(function() {

        $('.inputs').append(`<fieldset class="fieldset fieldset-agregado">
            <legend>Empleado</legend>
            <ul>
            <li>
               <label for="nom">Nombre y apellido:</label>
               <input type="text" id="nom"   name="empleado[nom][${num}]" placeholder="Ej: Sandra Perez" required >
            </li>
            <li>
               <label for="dni">DNI:</label>
               <input type="text" id="dni" name="empleado[dni][${num}]"  maxlength="8" required pattern="[0-9]{8}" placeholder="Ej: 33569356"  >
            </li>
            <li>
               <label for="emp">Empresa:</label>
               <input type="text" id="emp" name="empleado[emp][${num}]" title="poner razon social de empresa para la que va a trabajar" placeholder="Ej: poner razon social de empresa para la que va a trabajar"   >
            </li>
            <li>
               <label for="puesto">Puesto:</label>
               <input type="text" id="puesto" name="empleado[puesto][${num}]" required placeholder="Ej: chofer"   >
            </li>
            <li id="examen">
               <label for="exa">Examen:</label>
               <select id="exa" name="empleado[exa][${num}]" style="width:80%; padding:10px;" >
                  <option value="Preocupacional"selected>Examen Preocupacional</option>
                  <option value="Periódico">Examen Periódico</option>
                  <option value="Egreso">Examen Egreso</option>
                  <option value="Cambio de tareas">Cambio de tareas </option>
               </select>
            </li>
           </ul>
           <fieldset class="fieldset" id="estudios">
               <legend>Estudios a realizar</legend>
               <ul>
                         <span>Ver tipos de estudios que se realizan en la sección <a href="servicios.php"> SERVICIOS</a></span>
                     <li><textarea name="empleado[estudios][${num}]" id="estudios" style="width:90%; margin:auto; font-size:1rem; padding:10px;" cols="30" rows="10" >Bàsico (Resolucion, ECG, RX TORAX(F))
Laboratorio:                    
Psicotecnico                      
                     </textarea></li>               
                     
                     </ul>
               
           </fieldset>
            <div class="agregar">
            <input type="button" class="eliminar" onclick="eliminar(this)" value="Eliminar empleado" />
              
            </div>
           
           </fieldset>`);
        $num = num++;
        var $n = $(".fieldset-agregado #nom");
        var $p = $(".fieldset-agregado #puesto");
        
        $n.each(function() {
            $(this).blur(validarNom);

            function validarNom() {

                if ($(this).val().length < 1) {
                    $(this).addClass("error");
                    $('#dialog-input .parra').text("El nombre del empleado es requerida");
                    $("#dialog-input").dialog({
                         modal: true,
                         buttons: {
                            Ok: function() {
                              $(this).dialog("close");

                            }
                         }
                     });
                    return false;
                } else {
                    $(this).addClass("sucess");
                    return true;
                }
            }
        });

        
        $p.each(function() {


            $(this).blur(validarPuesto);

            function validarPuesto() {

                if ($(this).val().length < 1) {
                    $(this).addClass("error");
                    $('#dialog-input .parra').text("El puesto es requerido");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
                    return false;
                } else {
                    $(this).addClass("sucess");
                    return true;
                }
            }
        });
        
      //llenar input contar para hacer el forech de empleado

        var con = $('.fieldset-agregado').length;
        $contar = $('#contar').val(con);

        //localStorage.setItem(contar, contar);


    });

    eliminar = function(obj) {
            $(obj).closest(".fieldset-agregado").remove();
            $num = num--;
        }
        
        
    //$('#contar').val(localStorage.getItem(contar));
        // VALIDAR INPUTS


    var empresa = $("#empresa");
    var cuit = $("#cuit");
    var remitente = $("#remitente");
    var dir = $("#dir");
    var tel = $("#tel");
    var mail = $("#email");
    var asunto = $("#asunto");




    empresa.blur(validarEmpresa);
    remitente.blur(validarRe);
    dir.blur(validarDir);
    tel.blur(validarTel);
    cuit.blur(validarCuit);
    mail.blur(validarMail);
    asunto.blur(validarAsu);


    function validarEmpresa() {
        if (empresa.val().length < 1) {
            empresa.addClass("error");
            $('#dialog-input .parra').text("El nombre de la empresa requerido");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else {
            empresa.addClass("sucess");
            return true;
        }
    }

    function validarRe() {
        if (remitente.val().length < 1) {
            remitente.addClass("error");
            $('#dialog-input .parra').text("El remitente es requerido");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else {
            remitente.addClass("sucess");
            return true;
        }
    }

    function validarCuit() {

        if (cuit.val().length < 1) {
            cuit.addClass("error");
            $('#dialog-input .parra').text("El CUIT o DNI es requerido");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else if (!cuit.val().match(/^[0-9]{2}[\-][0-9]{8}[\-][0-9]{1}$/)) {
            cuit.addClass("error");
            $('#dialog-input .parra').text("El CUIT o DNI es incorrecto. Debe ingresar: 27-33068624-9 o 33068624");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else {
            cuit.addClass("sucess");
            return true;
        }
    }

    function validarTel() {
        if (tel.val().length < 1) {
            tel.addClass("error");
            $('#dialog-input .parra').text("El telefono es requerido");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else {
            tel.addClass("sucess");
            return true;
        }
    }

    function validarMail() {
        if (mail.val().length < 1) {
            mail.addClass("error");
            $('#dialog-input .parra').text("El mail es requerido");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else if (!mail.val().match(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/)) {
            mail.addClass("error");
            $('#dialog-input .parra').text("El mail es incorrecto debe ingresar ej: algo@hotmail.com");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else {
            mail.addClass("sucess");
            return true;
        }
    }

    function validarDir() {
        if (dir.val().length < 1) {
            dir.addClass("error");
           $('#dialog-input .parra').text("La direccion es requerida");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else {
            dir.addClass("sucess");
            return true;
        }
    }

    function validarAsu() {
        if (asunto.val().length < 1) {
            asunto.addClass("error");
            $('#dialog-input .parra').text("El asunto es requerido");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else {
            asunto.addClass("sucess");
            return true;
        }
    }







    $("#contact-form").submit(function(e) {
        $('#barra').show();
        var form_data = new FormData($(this)[0]);
            
        $.ajax({
            url: '../mails/mail.php',
            data: form_data,
            type: 'POST',
            processData: false,
            contentType: false,
            success: function() {
                $('#barra').hide();
                $("#dialog").dialog({
                    modal: true,
                    buttons: {
                        Ok: function() {
                            $(this).dialog("close");
                            $(location).attr('href', 'index.php');

                        }
                    }
                });

            },
            error: function(xhr, ajaxOptions, thrownError) {
                $('#barra').hide();
                $("#dialog-danger").dialog({
                    modal: true,
                    buttons: {
                        Ok: function() {
                            $(this).dialog("close");
                            $(location).attr('href', 'examen.php');
                        }
                    }
                });
            }
        });
        e.preventDefault();
    });






});