$(document).ready(function() {
    var menu = $('.menu nav');
    var menu2 = $('.menu2');
    if ($(window).width() < 800) {
        $('.menu nav ul li').css({ "border-bottom": "1px solid white" })
            .css({ "width": "100%" })
            .css({ "padding": "2px 0" });
        menu2.click(function() {
            menu.slideToggle();
        });

        $('.menu nav ul li').click(function() {
            menu.slideUp(slow);
        });
    }


    if (window.location.href.indexOf('index') > -1) {

        //slider
        var actual = 0;
        var elementos = $('.banner_item');
        var cantidadElementos = elementos.length;

        function slider() {
            var cogerActual = $('.banner_item').eq(actual);
            elementos.hide();
            cogerActual.css('display', 'block');
        }
        var autoSlide = setInterval(function() {
            actual += 1;
            if (actual > cantidadElementos - 1) {
                actual = 0;
            }
            slider();
        }, 5000);

    }

    if (window.location.href.indexOf('servicios') > -1) {
        $(".servicio").accordion({
            icons: {
                "header": "ui-icon-plus",
                "activeHeader": "ui-icon-minus"
            },
            classes: {
                "ui-accordion": "highlight"
            },

            heightStyle: "auto",
            animate: 200,
            collapsible: true,
            header: "h3"

        });
    }



   



    

   


});