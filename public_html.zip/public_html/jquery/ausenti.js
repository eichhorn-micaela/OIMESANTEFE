$(document).ready(function() {

    let num = 0;

    $('#btnAdd').click(function() {
       
        $('.inputs').append(`<fieldset class="fieldset fieldset-agregado">
        <legend>Empleado</legend>
              <ul>
              <li>
                 <label for="nom">Nombre y apellido:</label>
                 <input type="text" id="nom" name="empleado[nom][${num}]" placeholder="Ej: Sandra Perez" required >
              </li>
              <li>
                 <label for="emp">Empresa:</label>
                 <input type="text" id="emp" name="empleado[emp][${num}]" title="poner razon social de empresa para la que va a trabajar" placeholder="Ej: poner razon social de empresa para la que va a trabajar"   >
              </li>
              <li>
                 <label for="motivo">Motivo:</label>
                 <select id="motivo" name="empleado[motivo][${num}]" style="width:80%; padding:10px;" onchange="if(this.value=='Familiar'){$('#familia${num}').css('display','block'); $('#familia${num} textarea').attr('required', 'true');}else{$('#familia${num}').css('display','none'); $(' #familia${num} textarea').attr('required', 'false');('#familia${num} textarea').attr('placeholder', ' - ');}">
                    <option value="Enfermedad propia">Enfermedad propia</option>
                    <option value="Familiar">Por familiar</option>
                 </select>
              </li>
              <li id="familia${num}" style="display:none;">
                <textarea name="empleado[familiar][${num}]" id="familiar" cols="30"  rows="5" style="width:100%; padding:5px;" placeholder="Datos del familiar"></textarea>
              </li>
              
              <li>
                 <label for="tipo">Tipo de ausentismo:</label>
                 <select id="tipo" name="empleado[tipo][${num}]" style="width:80%; padding:10px;" onchange="if(this.value=='Domicilio'){$('#domi${num}').css('display','block'); $('#domi${num} textarea').attr('required', 'true');}else{$('#domi${num}').css('display','none'); $('#domi${num} textarea').attr('required', 'false');$('#domi${num} textarea').attr('placeholder', ' - ');}">
                    <option value="Consultorio">Consultorio</option>
                    <option value="Domicilio">Domicilio</option>
                 </select>
              </li>
              <li id="domi${num}" style="display:none;">
                <textarea name="empleado[domicilio][${num}]" id="domicilio" cols="30" rows="5" style="width:100%; padding:5px;" placeholder="Datos del domicilio y patología"></textarea>
              </li>
              
             </ul>
        <div class="agregar">
        <input type="button" class="eliminar" onclick="eliminar(this)" value="Eliminar empleado" />
          
        </div>
       
       </fieldset>`);

        $num = num++;


        var $n = $(".fieldset-agregado #nom");
        
        var $f = $(".fieldset-agregado #familiar");
        var $d = $(".fieldset-agregado #domicilio");



        $n.each(function() {
            $(this).blur(validarNom);

            function validarNom() {

                if ($(this).val().length < 1) {
                    $(this).addClass("error");
                    $('#dialog-input .parra').text("El Nombre del empleado es requerido");
                    $("#dialog-input").dialog({
                     modal: true,
                        buttons: {
                          Ok: function() {
                          $(this).dialog("close");

                    }
                }
            });
                    return false;
                } else {
                    $(this).addClass("sucess");
                    return true;
                }
            }
        });


        
        $f.each(function() {
            $(this).blur(validarFamiliar);

            function validarFamiliar() {

                if ($(this).val().length < 1) {
                    $(this).addClass("error");
                    $('#dialog-input .parra').text("Los datos del familiar son requeridos");
                     $("#dialog-input").dialog({
                         modal: true,
                         buttons: {
                             Ok: function() {
                             $(this).dialog("close");

                             }
                         }
                      });
                    return false;
                } else {
                    $(this).addClass("sucess");
                    return true;
                }
            }
        });
        $d.each(function() {


            $(this).blur(validarDireccion);

            function validarDireccion() {

                if ($(this).val().length < 1) {
                    $(this).addClass("error");
                    $('#dialog-input .parra').text("El Domicilio es requerido");
                    $("#dialog-input").dialog({
                        modal: true,
                        buttons: {
                           Ok: function() {
                           $(this).dialog("close");

                           }
                         }
                     });
                    return false;
                } else {
                    $(this).addClass("sucess");
                    return true;
                }
            }
        });
        //llenar input contar para hacer el forech de empleado

       var con = $('.fieldset-agregado').length;
        $contar = $('#contar').val(con);

        localStorage.setItem(contar, contar);



    });



    eliminar = function(obj) {
        $(obj).closest(".fieldset-agregado").remove();
        $num = num--;
    }
    //$('#contar').val(localStorage.getItem(contar));

    // VALIDAR INPUTS

   
    var empresa = $("#empresa");
    var cuit = $("#cuit");
    var remitente = $("#remitente");
    var dir = $("#dir");
    var tel = $("#tel");
    var mail = $("#email");





    empresa.blur(validarEmpresa);
    remitente.blur(validarRe);
    dir.blur(validarDir);
    tel.blur(validarTel);
    cuit.blur(validarCuit);
    mail.blur(validarMail);



    function validarEmpresa() {
        if (empresa.val().length < 1) {
            empresa.addClass("error");
            $('#dialog-input .parra').text("El Nombre de la empresa es requerido");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else {
            empresa.addClass("sucess");
            return true;
        }
    }

    function validarRe() {
        if (remitente.val().length < 1) {
            remitente.addClass("error");
            $('#dialog-input .parra').text("El remitente es requerido");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else {
            remitente.addClass("sucess");
            return true;
        }
    }

    function validarCuit() {

        if (cuit.val().length < 1) {
            cuit.addClass("error");
            $('#dialog-input .parra').text("El CUIT o DNI es requerido");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else if (!cuit.val().match(/^[0-9]{2}[\-][0-9]{8}[\-][0-9]{1}$/)) {
            cuit.addClass("error");
            $('#dialog-input .parra').text("El CUIT o DNI es incorrecto. Ingrese: 27-33068624-9 o 33068624");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else {
            cuit.addClass("sucess");
            return true;
        }
    }

    function validarTel() {
        if (tel.val().length < 1) {
            tel.addClass("error");
            $('#dialog-input .parra').text("El telefono es requerido");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else {
            tel.addClass("sucess");
            return true;
        }
    }

    function validarMail() {
        if (mail.val().length < 1) {
            mail.addClass("error");
            $('#dialog-input .parra').text("El mail es requerido");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else if (!mail.val().match(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/)) {
            mail.addClass("error");
            $('#dialog-input .parra').text("El mail es incorrecto. Ingresar ej: algo@hotmail.com");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else {
            mail.addClass("sucess");
            return true;
        }
    }

    function validarDir() {
        if (dir.val().length < 1) {
            dir.addClass("error");
            $('#dialog-input .parra').text("La direccion es requerida");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else {
            dir.addClass("sucess");
            return true;
        }
    }


















    $("#contact-form").submit(function(e) {
        $('#barra').show();
        var form_data = new FormData($(this)[0]);
       
        $.ajax({
            url: '../mails/mail-ausentismo.php',
            data: form_data,
            type: 'POST',
            processData: false,
            contentType: false,
            success: function() {
                $('#barra').hide();
                $("#dialog").dialog({
                    modal: true,
                    buttons: {
                        Ok: function() {
                            $(this).dialog("close");
                            $(location).attr('href', 'index.php');
                             

                        }
                    }
                });

            },
            error: function(xhr, ajaxOptions, thrownError) {
                $('#barra').hide();
                $("#dialog-danger").dialog({
                    modal: true,
                    buttons: {
                        Ok: function() {
                            $(this).dialog("close");
                            $(location).attr('href', 'ausentismo.php');
                        }
                    }
                });
            }
        });
        e.preventDefault();
    });






});