$(document).ready(function() {

    var empAdm = $("#empresa");
    var cuitAdm = $("#cuit");
    var remiAdm = $("#remitente");
    var dirAdm = $("#dir");
    var telAdm = $("#tel");
    var mailAdm = $("#email");
    var asuntoAdm = $("#asunto");




    empAdm.blur(validarEmpresa);
    remiAdm.blur(validarRe);
    dirAdm.blur(validarDir);
    telAdm.blur(validarTel);
    cuitAdm.blur(validarCuit);
    mailAdm.blur(validarMail);
    asuntoAdm.blur(validarAsu);


    function validarEmpresa() {
        if (empAdm.val().length < 1) {
            empAdm.addClass("error");
            $('#dialog-input .parra').text("El nombre de la empresa es requerido");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else {
            empAdm.addClass("sucess");
            return true;
        }
    };

    function validarRe() {
        if (remiAdm.val().length < 1) {
            remiAdm.addClass("error");
            $('#dialog-input .parra').text("El remitente es requerido");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else {
            remiAdm.addClass("sucess");
            return true;
        }
    };

    function validarCuit() {

        if (cuitAdm.val().length < 1) {
            cuitAdm.addClass("error");
            $('#dialog-input .parra').text("El CUIT o DNI es requerido");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else if (!cuitAdm.val().match(/^[0-9]{2}?[\-]?[0-9]{8}[\-]?[0-9]{1}?$/)) {
            cuitAdm.addClass("error");
            $('#dialog-input .parra').text("El Cuit o dni es incorrecto: Debe ingresar 27-33068624-9 o 33068624");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else {
            cuitAdm.addClass("sucess");
            return true;
        }
    };

    function validarTel() {
        if (telAdm.val().length < 1) {
            telAdm.addClass("error");
            $('#dialog-input .parra').text("El telefono es requerido");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else {
            telAdm.addClass("sucess");
            return true;
        }
    };

    function validarMail() {
        if (mailAdm.val().length < 1) {
            mailAdm.addClass("error");
            $('#dialog-input .parra').text("El mail es requerido");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else if (!mailAdm.val().match(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/)) {
            mailAdm.addClass("error");
            $('#dialog-input .parra').text("El mail es incorrecto. Debe poner ej: algo@gmail.com");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else {
            mailAdm.addClass("sucess");
            return true;
        }
    };

    function validarDir() {
        if (dirAdm.val().length < 1) {
            dirAdm.addClass("error");
            $('#dialog-input .parra').text("La direccion es requerida");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else {
            dirAdm.addClass("sucess");
            return true;
        }
    };

    function validarAsu() {
        if (asuntoAdm.val().length < 1) {
            asuntoAdm.addClass("error");
            $('#dialog-input .parra').text("El asunto es requerido");
            $("#dialog-input").dialog({
                modal: true,
                buttons: {
                    Ok: function() {
                        $(this).dialog("close");

                    }
                }
            });
            return false;
        } else {
            asuntoAdm.addClass("sucess");
            return true;
        }
    };



    $("#contact-form").submit(function(e) {
        $('#barra').show();
        var form_data = new FormData($(this)[0]);
       
         
        $.ajax({
            url: '../mails/mail-administracion.php',
            data: form_data,
            type: 'POST',
            processData: false,
            contentType: false,
            success: function() {
                $('#barra').hide();
                $("#dialog").dialog({
                    modal: true,
                    buttons: {
                        Ok: function() {
                            $(this).dialog("close");
                            $(location).attr('href', 'index.php');

                        }
                    }
                });

            },
            error: function(xhr, ajaxOptions, thrownError) {
                $('#barra').hide();
                $("#dialog-danger").dialog({
                    modal: true,
                    buttons: {
                        Ok: function() {
                            $(this).dialog("close");
                            $(location).attr('href', 'aedministracion.php');

                        }

                    }
                });

            }

        });
        e.preventDefault();
    });



});