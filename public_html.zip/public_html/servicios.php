<?php include 'menu.php' ?>

<link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css">

<link rel="stylesheet"  href="css/servicios/servs.css">
<div class="wrap">
     <div class="titulo">
          <h2 style="color: #154360;">Nuestros servicios</h2>
     </div>
        <section class="intro">
            <div class="texto">
                 <p style="color: #154360;">Realizamos los exámenes de salud de prevención a los empleados de empresas, de acuerdo al marco legal vigente y teniendo en cuenta las características de la actividad desarrollada. Nos caracterizamos por ofrecer un modelo de gestión integral, ofreciéndole a nuestros clientes una solución en materia laboral, garantizando el seguimiento para la realización de los exámenes, la mayor celeridad en las prestaciones y en la información de las mismas. </p>
            </div>
        </section>
        <section class="contenido-servicios">
            <h2 style="color: #154360;">Los servicios que prestamos</h2>
            <hr>
            <div class="servicios">
                <div class="servicio">
                    <h3 >Exámenes Pre ocupacionales</h3>
                    <div>Tienen como objetivo determinar la capacidad psicofísica de los futuros empleados, para evaluar si se encuentran en condiciones de realizar las tareas que se les asignen, evitando riesgos para los postulantes.</div>
                    <h3>Exámenes Periódicos</h3>
                    <div> Tienen como objetivo evaluar periódicamente la salud del trabajador, a fin de encontrar patologías que determinen un riesgo en su salud, con el propósito de aplicar las soluciones más convenientes en forma oportuna.</div>
                    <h3>Previo al cambio de actividad</h3>
                    <div>Se realiza en aquellos casos en que el trabajador, ante un cambio de actividad quede expuesto a agentes de riesgos.</div>
                    <h3>Examen tras ausencia prolongada</h3>
                    <div>Se recomienda realizarlo cuando el personal se ausenta de su puesto de trabajo por un período superior a 6 meses.</div>
                    <h3>Examen de Egreso</h3>
                    <div>Se recomienda su realización en todos aquellos casos en que el empleado se desvincule de la empresa.</div>
                </div>
                <div class="servicio">
                    <h3>Carpeta medica</h3>
                    <div>Realizamos estudios para el ingreso a la policia  o prefectura. Para la renovación de libreta de embarque y para aptos deportivos</div>
                    <h3>Control de ausentismo</h3>
                    <div>Se recomienda su realización para  contar con la información del porque su empleado no esta concurriendo a su trabajo, si existe razón medica justificable y si esta cumpliendo con los tratamientos adecuados.</div>
                    <h3>CLU y portación de armas</h3>
                    <div>Somos prestadores oficiales de ANMAC para realizar los estudios correspondientes para la credencial de legitimo usuario y portación de armas</div>
                    <h3>Capacitaciones</h3>
                    <div>Realizamos cursos de primeros auxilios y charlas informativas sobre tabaco, obecidad entre otras.</div>
                    <h3>Campaña de vacunación antigripal</h3>
                    <div>Anualmente se realiza la misma , ofreciendo las vacunas para todo el personal de las empresas.</div>
                </div>
            </div>
        </section>
        <section class="contenido-estudios">
            <h2 style="color: #154360;">Los estudios que realizamos por especialista</h2>
            <hr>
            <p >Los estudios que deben realizarse difieren según sea la actividad realizada por el empleado en función a los agentes de riesgos que cada una presenta.</p>
            <div class="estudios">
                <div class="estudio">
                    <div class="cabecera">
                        <img src="images/clinico.png" width="50px" alt="">
                        <h3>Médico clínico</h3>
                    </div>
                    <div class="lista">
                        <ul>
                            <li>Agudeza visual clínica</li>
                            <li>Declaración Jurada de enfermedades preexistentes</li>
                            <li>Antecedentes familiares</li>
                            <li>Peso e índice de Masa Corporal</li>
                            <li>Evaluación clínica de todos los aparatos y sistemas</li>
                            <li>Determinación de la aptitud laborativa</li>
                        </ul>
                    </div>
                </div>
                <div class="estudio">
                    <div class="cabecera">
                        <img src="images/laboratorio.png" width="50px" alt="">
                        <h3>Bioquímico</h3>
                    </div>
                    <div class="lista">
                        <ul>
                            <li><u>Resolucion:</u> hemograma, uremia, eritrosedimentación, glucosa y orina</li>
                            <li><u>Hepatograma:</u> Albúmina,  Bilirrubina, Fosfatasa alcalina, Transaminasa alcalina (ALT), etc</li>
                            <li><u>Perfil lipídico:</u> Colesterol total, HDL,LDL y trigliceridos</li>
                            <li><u>Perfil drogas:</u> Cocaina, marihuana, anfetaminas, extasis, opiaceos, etc</li>
                            <li><u>Laboratorio para libreta sanitaria completa</u> </li>
                            <li>Hepatitis, HIV, Alcoholemia, Huddleson</li>
                            <li>Gravindex / Unidad sub-beta</li>
                        </ul>
                    </div>
                </div>
                <div class="estudio">
                    <div class="cabecera">
                    <img src="images/corazon.png" width="50px" alt="">
                        <h3>Cardiólogo</h3>
                    </div>
                    <div class="lista">
                        <ul>
                            <li>Electrocardiograma</li>
                            <li>Examen cardiológico</li>
                            <li>Ergometría</li>
                        </ul>
                    </div>
                </div>
                <div class="estudio">
                    <div class="cabecera">
                    <img src="images/cerebro.png" width="50px" alt="">
                        <h3>Neurólogo</h3>
                    </div>
                    <div class="lista">
                        <ul>
                            <li>Electroencefalograma</li>
                            <li>Examen neurológico</li>
                            <li>Examen de reflejos</li>
                            <li>Videonistagmografia / Equilibriometría</li>
                        </ul>
                    </div>
                </div>
                <div class="estudio">
                    <div class="cabecera">
                    <img src="images/oido.png" width="50px" alt="">
                        <h3>Fonoaudiólogo</h3>
                    </div>
                    <div class="lista">
                        <ul>
                            <li>Audiometría vocal o verbal</li>
                            <li>Audiometría tonal
                            <ul>
                                <li>Audiometría tonal liminar o de umbral</li>
                                <li>Audiometría tonal supraliminar</li>
                            </ul>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="estudio">
                    <div class="cabecera">
                    <img src="images/psico.png" width="50px" alt="">
                        <h3>Psicólogo</h3>
                    </div>
                    <div class="lista">
                        <ul>
                            <li>Psicotécnico</li>
                            <li>Entrevista personal</li>
                            <li>Psicodiagnóstico</li>
                            <li>Test de evaluación: test de raven, hombre bajo la lluvia, test de bender, etc</li>
                        </ul>
                    </div>
                </div>
                <div class="estudio">
                    <div class="cabecera">
                    <img src="images/psiquiatra.png" width="50px"  alt="">
                        <h3>Psiquiatra</h3>
                    </div>
                    <div class="lista">
                        <ul>
                            <li>Evaluación psiquiátrica</li>
                        </ul>
                    </div>
                </div>
                <div class="estudio">
                    <div class="cabecera">
                    <img src="images/pulmon.png" width="50px" alt="">
                        <h3>Otorrinolaringólogo</h3>
                    </div>
                    <div class="lista">
                        <ul>
                            <li>Laringoscopía</li>
                        </ul>
                    </div>
                </div>
                <div class="estudio">
                    <div class="cabecera">
                    <img src="images/lentes.png" width="50px" alt="">
                        <h3>Oftalmólogo</h3>
                    </div>
                    <div class="lista">
                        <ul>
                            <li>Agudeza visual cercana y lejana con y sin contraste</li>
                            <li>Test de isihara</li>
                            <li>Visión cromática</li>
                            <li>Fondo de ojos</li>
                            <li>Campimetría</li>
                            <li>Test de colores de farnsworth 15</li>
                        </ul>
                    </div>
                </div>
                <div class="estudio">
                    <div class="cabecera">
                    <img src="images/pulmon.png" width="50px" alt="">
                        <h3>Neumonólogo</h3>
                    </div>
                    <div class="lista">
                        <ul>
                            <li>Espirometría</li>
                            <li>Polisomnografía (estudio del sueño)</li>
                        </ul>
                    </div>
                </div>
               
                <div class="estudio">
                    <div class="cabecera">
                    <img src="images/hueso.png" width="50px" alt="">
                        <h3>Traumatólogo</h3>
                    </div>
                    <div class="lista">
                        <ul>
                            <li>Evaluación traumatológica</li>
                        </ul>
                    </div>
                </div>
                <div class="estudio">
                    <div class="cabecera">
                    <img src="images/radiology-icon.png" width="50px" alt="">
                        <h3>Radiologia</h3>
                    </div>
                    <div class="lista">
                        <ul>
                            <li>Radiografía de Tórax</li>
                            <li>Radiografía de Columna lumbo sacra</li>
                            <li>Radiografía de Columna cervical</li>
                            <li>Radiograías varias</li>
                            <li>Resonancia Nuclear Magnetica</li>
                            <li>Ecografías varias</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
</div>


<?php include 'footer.php' ?>