<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'VENDOR/vendor/autoload.php';



 $destino = "oimesantafe@fibertel.com.ar";
 $empresa = trim($_POST['empresa']);
 $cuit = trim($_POST['cuit']);
 $remitente = trim($_POST['remitente']);
 $tel=trim($_POST['tel']);
 $dir=trim($_POST['dir']);
 $email =trim($_POST['email']);
 $asunto =trim( $_POST['asunto']);
 $empleado=$_POST['empleado'];
 $contar=$_POST['contar'];
 
 
 
 
$mail = new PHPMailer;
 try{
    $mail->CharSet = "utf-8";
    $mail->SMTPDebug =2; 
    $mail->isSMTP(); 
    $mail->Host = 'smtp.hostinger.com.ar';
    $mail->SMTPAuth   = true;                                   
    $mail->Username   = 'contacto.oime@oimesantafe.com';                   
    $mail->Password   = 'oimesantafe';                               
    $mail->SMTPSecure = 'tls';        
    $mail->Port = 587;                                   

    //Recipients
    $mail->setFrom('contacto.oime@oimesantafe.com', $empresa);
    $mail->addAddress($destino);
    $mail->addReplyTo($email);   
    // Add a recipient
    if(isset( $_POST['copia'])){
      $mail->addBCC($email);}             
 

    


$archivoTmp=$_FILES['file']['tmp_name'];
      $archivoName=$_FILES['file']['name'];
      
      $i = 0;
    foreach ($archivoTmp as $rutas_archivos) {
        $mail->AddAttachment($rutas_archivos,$archivoName[$i]);
        $i++;
    }
   
 
  
       
 
$html="
<html>
<head>
<style>
table {
border: 1px solid black;
background-color: white;
margin-bottom: 20px;
}
table thead {
background-color: lightgray;
}
table th {
padding: 5px;
width: 200px;
border: 1px solid black;
}
table td {
width: 200px;
padding: 5px;
border: 1px solid black;
}
table td:last-child {
width: auto;
border: none!important;
}
</style>
</head>
<body>
<h3>Recibiste un nuevo mensaje desde el formulario de contacto de https://oimesantafe.com/</h3>
<hr>

<p><strong>Empresa a facturar:</strong> {$empresa}</p>
<p><strong>CUIT:</strong> {$cuit}</p>
<p><strong>Direccion:</strong> {$dir}</p>
<p><strong>Remitente:</strong> {$remitente}</p>
<p><strong>Telefono de contacto:</strong> {$tel}</p>
<p><strong>Mail:</strong> {$email}</p>
<hr>
<br>
<br>

<h3>Detalle de el o los empleados </h3>
<br>
<br>

<table >
        <thead>
          <tr>
             <th>Nombre</th>
             <th>DNI</th>
             <th>Empresa</th>
             <th>Puesto</th>
             <th>Tipo de examen</th>
             <th>Estudios</th>
          </tr>
         </thead>
         

";

for($i=0;$i<=$contar;$i++){
$html.="
     <tbody>
           <tr>
         
              <td>".$empleado['nom'][$i]."</td>
              <td>".$empleado['dni'][$i]."</td>
              <td>".$empleado['emp'][$i]."</td>
              <td>".$empleado['puesto'][$i]."</td>
              <td>".$empleado['exa'][$i]."</td>
              <td>".$empleado['estudios'][$i]."</td>";
    
 }


$html.="</tr>
    </tbody>
    </table> 
    </body></html>";


    // Content
    $mail->isHTML(true);                                  
    $mail->Subject = $asunto;
    $mail->AltBody= $html;
    $mail->Body =$html;

 $mail->send();
 
} catch (Exception $e) {
   $mail->ErrorInfo;
}

?>