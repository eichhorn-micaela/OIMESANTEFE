<?php


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'VENDOR/vendor/autoload.php';


 $destino = "administracion.oime@fibertel.com.ar";
 $empresa = trim($_POST['empresa']);
 $cuit = trim($_POST['cuit']);
 $remitente = trim($_POST['remitente']);
 $tel=trim($_POST['tel']);
 $dir=trim($_POST['dir']);
 $email =trim($_POST['email']);
 $asunto =trim( $_POST['asunto']);
 $mensaje=$_POST['mensaje'];

$mail = new PHPMailer;
 try{
  
    $mail->CharSet = "utf-8";
    $mail->SMTPDebug =0; 
    $mail->isSMTP(); 
    $mail->SMTPKeepAlive = true;
    $mail->Host = 'smtp.hostinger.com.ar';
    $mail->SMTPAuth   = true;  
    $mail->Username   = 'contacto.oime@oimesantafe.com';                   
    $mail->Password   = 'oimesantafe';                               
    $mail->SMTPSecure = 'tls';        
    $mail->Port = 587;                                   

    //Recipients
    $mail->setFrom('contacto.oime@oimesantafe.com', $empresa);
    $mail->addAddress($destino);
    $mail->addReplyTo($email);   
    // Add a recipient
    if(isset( $_POST['copia'])){
      $mail->addBCC($email);}             
    

    // adjuntos
    
      
      $archivoTmp=$_FILES['file']['tmp_name'];
      $archivoName=$_FILES['file']['name'];
      
      $i = 0;
    foreach ($archivoTmp as $rutas_archivos) {
        $mail->AddAttachment($rutas_archivos,$archivoName[$i]);
        $i++;
    }
      
   
      

          
            
   
   
    
    $html="
<html>
<head>

</head>
<body>
<h3>Recibiste un nuevo mensaje desde el formulario de contacto de https://oimesantafe.com/</h3>
   <hr>
  
   <p><strong>Empresa a facturar:</strong> {$empresa}</p>
   <p><strong>CUIT:</strong> {$cuit}</p>
   <p><strong>Direccion:</strong> {$dir}</p>
   <p><strong>Remitente:</strong> {$remitente}</p>
   <p><strong>Telefono de contacto:</strong> {$tel}</p>
   <hr>
   <br>
   <br>
   
   <h3><u>Mensaje</u></h3>
   <br>
   <br>
   
   <div>{$mensaje}</div>
    
        
        <body>
        <html>";
   
  
    // Content
    $mail->isHTML(true);                                  
    $mail->Subject = $asunto;
    $mail->AltBody= $html;
    $mail->Body =$html;

    $mail->send();
} catch (Exception $e) {
   $mail->ErrorInfo;
}
?>