<?php include 'menu.php' ?>
<link rel="stylesheet"  href="css/nosotros/nost.css">
<div class="wrap">
     <div class="titulo">
          <h2 style="color: #154360;">Sobre nosotros</h2>
     </div>
        <section class="intro">
            <div class="texto">
                 <p style="color: #154360;">Desde Abril de 1986 a la Vanguardia de la Medicina Laboral y La Salud Ocupacional.
                  Es la Primera Institución fundada y organizada con dedicación   exclusiva en  Medicina  Laboral de la ciudad de Santa Fe, para el respaldo del Empresario Santafesino. </p>
            </div>
        </section>
        <section class="cards">
             <div class="card">
                 <div class="imagen">
                <img src="images/vision.webp" alt="vision">
               </div>
				<h2 class="categoria">Vision</h2>
				<p class="descripcion">
					Aprende los principales lenguajes para desarrollar web ¡Combiertete en web master!
				</p>
            </div>
            <div class="card">
                <div class="imagen">
                <img src="images/mision.png" alt="mision">
                </div>
				<h2 class="categoria">Mision</h2>
				<p class="descripcion">
					Aprende los principales lenguajes para desarrollar web ¡Combiertete en web master!
				</p>
            </div>
            <div class="card">
                <div class="imagen">
                <img src="images/valores.png" alt="valores">
                 </div>
				<h2 class="categoria">Valores</h2>
				<p class="descripcion">
					Aprende los principales lenguajes para desarrollar web ¡Combiertete en web master!
				</p>
			</div>
        </section>
        <section class="galeria">
            <div class="imagen">
                <img src="images/sala-espera1.jpg" alt="Sala de espera principal">
            </div>
            <div class="imagen">
                <img src="images/neurologia-oime.jpg" alt="Consultorio de neurologia">
            </div>
            <div class="imagen">
                <img src="images/cardiologia-oime.jpg" alt="Consultorio de cardiologia">
            </div>
            <div class="imagen">
                <img src="images/sala-de-espera2.jpg" alt="Sala de espera secundaria">
            </div>
            <div class="imagen">
                <img src="images/pasillo-oime.jpg" alt="pasillo interno">
            </div>
            <div class="imagen">
                <img src="images/puerta.jpg" alt="puerta de ingreso">
            </div>
            <div class="imagen">
                <img src="images/imagen4.jpg" alt="imagen 4">
            </div>
            <div class="imagen">
                <img src="images/imagen8.jpg" alt="imagen 8">
            </div>
        </section>
</div>

<?php include 'footer.php' ?>